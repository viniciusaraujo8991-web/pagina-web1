# 🚀 Guia Rápido - Bet365 Odds Helper

## ⚡ Instalação em 3 passos

### 1️⃣ Abrir extensões do Chrome
Digite na barra de endereços: **`chrome://extensions/`**

### 2️⃣ Ativar modo desenvolvedor
Clique no botão **"Modo do desenvolvedor"** (canto superior direito)

### 3️⃣ Carregar extensão
1. Clique em **"Carregar sem compactação"**
2. Selecione a pasta **`Under_limite`**
3. Pronto! ✅

---

## 📱 Como usar

### Passo 1: Abrir Bet365
Acesse um evento com mercado de **gols** (Over/Under)

### Passo 2: Clicar no ícone da extensão
O popup mostrará:

```
┌─────────────────┐       ┌─────────────────┐
│ Bet365 Under    │   →   │ Betfair Alvo    │
│      1.72       │       │      1.85       │
└─────────────────┘       └─────────────────┘
```

### Passo 3: Comparar com Betfair
Abra a Betfair Exchange e veja a odd atual de back ao under.

## 💡 Exemplo Real

### Situação:
- **Bet365 Under:** 1.72
- **Betfair Alvo (tabela):** 1.85
- **Betfair atual:** 1.90

### Decisão:
✅ **ENTRE!** Porque 1.90 > 1.85  
O mercado deve cair para 1.85, você lucra na diferença.

---

## 🎯 Seu Método de Trading

1. Bet365 mostra Under em 1.72
2. Pela tabela, você sabe que na Betfair deveria estar ~1.85
3. Se Betfair paga 1.90+ = **ENTRADA** (vai cair para 1.85)
4. Se Betfair já está em 1.85 ou menos = **NÃO ENTRA** (mercado junto)

---

## ⚙️ Configurações

Não há configurações! A extensão funciona automaticamente:
- ✅ Captura odds de Under da Bet365
- ✅ Busca valor correspondente na tabela
- ✅ Mostra os dois valores lado a lado
- ✅ Atualiza automaticamente a cada 3 segundos

---

## 🐛 Problemas?

### Não captura odds
1. Verifique se está em uma página de evento
2. Recarregue a página (F5)
3. Abra o console (F12) e procure erros

### Popup não abre
1. Verifique se a extensão está ativada em `chrome://extensions/`
2. Clique com botão direito no ícone > "Inspecionar popup"

---

## 📊 Tabela de Referência

A extensão usa uma tabela com valores de referência:

| Bet365 | Betfair Alvo |
|--------|--------------|
| 1.72   | 1.85         |
| 1.66   | 1.78         |
| 1.61   | 1.71         |
| 1.57   | 1.68         |
| 1.53   | 1.62         |
| 1.50   | 1.60         |

Tabela completa em `odds-reference.json`

---

## ✅ Checklist

- [ ] Chrome instalado
- [ ] Extensão carregada em `chrome://extensions/`
- [ ] Modo desenvolvedor ativado
- [ ] Ícone visível na barra de ferramentas
- [ ] Testado em evento da Bet365
- [ ] Popup abre ao clicar no ícone

---

**Pronto para usar! Bons trades! 🎯💰**
