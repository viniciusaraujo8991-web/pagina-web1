var firebaseConfig = {
  apiKey: "AIzaSyARb5I3bR9gOYJcDFCA7aDuTkN8lpV1jT0",
  authDomain: "under-limite.firebaseapp.com",
  databaseURL: "https://under-limite-default-rtdb.firebaseio.com",
  projectId: "under-limite",
  storageBucket: "under-limite.firebasestorage.app",
  messagingSenderId: "998652296627",
  appId: "1:998652296627:web:00683ac262a4fc6f3b1fc6"
};